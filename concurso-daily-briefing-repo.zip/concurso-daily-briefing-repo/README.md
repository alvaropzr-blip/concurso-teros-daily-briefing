# Concurso Teros — Mejor Daily Briefing Personal

Landing page del concurso de comunidad de Teros AI.

## URL del concurso

Una vez desplegado: `https://[tu-org].github.io/concurso-daily-briefing/`

## Cómo desplegar en GitHub Pages

### Opción A: Deploy desde branch (más simple)

1. Crea un repo nuevo en GitHub: `concurso-daily-briefing`
2. Sube estos archivos al repo (main branch)
3. Ve a **Settings > Pages** del repo
4. En "Build and deployment", selecciona:
   - **Source:** Deploy from a branch
   - **Branch:** main
   - **Folder:** / (root)
5. Guarda y espera 1-2 minutos
6. La URL será: `https://[tu-usuario].github.io/concurso-daily-briefing/`

### Opción B: Deploy con GitHub Actions

1. Crea el repo y sube los archivos
2. Ve a **Settings > Pages**
3. En "Build and deployment", selecciona **GitHub Actions**
4. El workflow `.github/workflows/deploy.yml` ya está incluido
5. Cualquier push a main desplegará automáticamente

## Contenido

- `index.html` — Landing del concurso con diseño Teros
- Diseño responsive, dark mode, tipografía Georgia + system-ui

## Modificaciones

Edita directamente `index.html`. Los cambios se reflejan tras el próximo deploy.
